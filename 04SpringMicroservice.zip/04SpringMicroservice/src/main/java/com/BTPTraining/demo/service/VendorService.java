package com.BTPTraining.demo.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.BTPTraining.demo.entities.Vendor;

@Component
public class VendorService {

	HashMap<String, Vendor> vendors = new HashMap<String, Vendor>();
	
	@Autowired
	Vendor ven1;
	@Autowired
	Vendor ven2;
	@Autowired
	Vendor ven3;
	
	private void fillVendors() {
		//WA to Itab
		vendors.put("1", ven1);
		vendors.put("2", ven2);
		vendors.put("3", ven3);
	}
	

	public void vendorService() {
		fillVendors();
	}





	public HashMap<String, Vendor> getAllVendors(){
		fillVendors();
		return vendors;
	}
	
	public Vendor getVendorByKey(String VendorId) {
		fillVendors();
		//Read table with Key
	    return (Vendor)vendors.get(VendorId);	
	}
	
	public Vendor createVendor(Vendor Vendor) {
		fillVendors();
	     vendors.put("4", Vendor);
	     return Vendor;
	}
	
	public Vendor updateVendor(Vendor Vendor) {
		fillVendors();
		return Vendor;
	} 
	
	public void deleteVendor(String VendorId) {
		fillVendors();
		vendors.remove(VendorId);
	}
}

package com.BTPTraining.demo.classes;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component

public class SamsungHDD implements IHDD {

	@Override
	public String read() {
		// TODO Auto-generated method stub
		return "Samsung HDD is reading data at 10K RPM";
	}

	@Override
	public String write() {
		// TODO Auto-generated method stub
		return "Samsung HDD is writing data at 5K RPM";
	}

}

package com.BTPTraining.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.BTPTraining.demo.classes.Laptop;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(DemoApplication.class, args);
		Laptop lenevo = context.getBean(Laptop.class);
		
		lenevo.setBrandname("Lenevo");
		lenevo.setLenght(15);
		lenevo.setWeight(2);
		lenevo.setWidth(3);
		System.out.println(lenevo.toString());
	}

}

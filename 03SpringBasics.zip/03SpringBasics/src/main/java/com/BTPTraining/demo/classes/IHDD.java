package com.BTPTraining.demo.classes;

public interface IHDD {

	public String read();
	
	public String write();
}

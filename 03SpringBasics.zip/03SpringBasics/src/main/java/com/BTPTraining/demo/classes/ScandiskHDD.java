package com.BTPTraining.demo.classes;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class ScandiskHDD implements IHDD {

	@Override
	public String read() {
		// TODO Auto-generated method stub
		return "Scandisk is reading data at 20K RPM";
	}

	@Override
	public String write() {
		// TODO Auto-generated method stub
		return "Scandisk is writing data at 10K RPM";
	}

}

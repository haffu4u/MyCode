package com.BTPTraining.demo.classes;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component

public class Laptop {

	private int lenght;
	private int width;
	private int weight;
	private String Brandname;
	
	@Autowired
	private IHDD hdd;
	
	@Override
	public String toString() {
		return "Laptop [lenght=" + lenght + ", width=" + width + ", weight=" + weight + ", Brandname=" + Brandname
				+"] and is running with " + hdd.read();
	}
	
	public Laptop() {
		super();
	}
	public int getLenght() {
		return lenght;
	}
	public void setLenght(int lenght) {
		this.lenght = lenght;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public String getBrandname() {
		return Brandname;
	}
	public void setBrandname(String brandname) {
		Brandname = brandname;
	}
	
	
}

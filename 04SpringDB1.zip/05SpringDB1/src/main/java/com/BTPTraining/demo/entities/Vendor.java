package com.BTPTraining.demo.entities;

import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class Vendor {


	private String code;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	private String companyName;

	private String contactPerson;

	private String firstName;

	private String lastName;

	private String website;

	private String email;

	private String status;

	private Date regdate;
	public Vendor() {
		super();
		this.code = "VEND1";
		this.companyName = "IBM Corp";
		this.contactPerson = "Simon Smith";
		this.firstName = "Laura";
		this.lastName = "Simpson";
		this.website = "www.ibm.com";
		this.email = "laura@ibm.com";
		this.status = "A";
		this.regdate = new Date();
	}
	@Override
	public String toString() {
		return "vendor [code=" + code + ", companyName=" + companyName + ", contactPerson=" + contactPerson
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", website=" + website + ", email=" + email
				+ ", status=" + status + ", regdate=" + regdate + "]";
	}
	
}

package com.BTPTraining.demo.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.BTPTraining.demo.entity.Vendor;

@Component
public interface IVenPersistence extends JpaRepository<Vendor, String> {

	List <Vendor> findByCompanyName(String companyName);
	
	@Query(nativeQuery=true, value="SELECT * FROM public.vendor where lower(first_name) like %?1% ")
	List<Vendor> lookupByFirstName(String firstName);



}

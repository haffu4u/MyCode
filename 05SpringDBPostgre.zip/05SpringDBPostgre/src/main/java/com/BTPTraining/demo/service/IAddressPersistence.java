package com.BTPTraining.demo.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.BTPTraining.demo.entity.Address;


public interface IAddressPersistence extends JpaRepository<Address, String> {

}
